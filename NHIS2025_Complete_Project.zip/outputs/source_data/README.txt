UNVERAENDERTE NHIS-2025-URSPRUNGSDATEN

adult25.csv ist die heruntergeladene und aus adult25csv.zip entpackte
Public-use-Erwachsenendatei, auf der die Analyse beruht: 24.215 Zeilen und
577 Spalten. Die erste Zeile enthaelt die Variablennamen. Es wurden keine
Zeilen ausgewaehlt, Werte umkodiert oder Variablen entfernt.

adultinc25.csv ist die zusaetzlich verwendete offizielle Einkommensdatei:
zehn Imputationen je Person. Sie ist ueber HHX und IMPNUM_A verknuepft.
Die Eintraege sind keine zehnfach unabhaengigen Personen.

Die ZIP-Dateien sind die unveraenderten heruntergeladenen Originalarchive.
SHA256.csv enthaelt Pruefsummen der vier Daten-Dateien.

Offizielle Quellen:
https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/2025/adult25csv.zip
https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/2025/adultinc25csv.zip
https://www.cdc.gov/nchs/nhis/documentation/2025-nhis.html

Codebook mit Codes, Fragewortlaut, Befragungsuniversen und Skip-Logik:
https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Dataset_Documentation/NHIS/2025/adult-codebook.pdf

CSV-Dateien sind direkt in R oder einer Tabellenkalkulation lesbar.
Die Daten sind offizielle Public-use-Mikrodaten, keine klinischen Befunde.
Die Analysestichprobe ab 65 Jahren und alle Umkodierungen werden erst im
R-Skript aus dieser vollstaendigen Datei abgeleitet.
