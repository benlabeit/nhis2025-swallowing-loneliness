NHIS 2025 ORIGINAL DATA SOURCES

Original respondent CSVs and ZIPs are not included in this package.
Run RunAll.ps1 from the extracted project root. The downloader retrieves missing
CDC archives, verifies fixed SHA-256 hashes and extracts the CSVs to work/raw/.

https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/2025/adult25csv.zip
https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/2025/adultinc25csv.zip
https://www.cdc.gov/nchs/nhis/documentation/2025-nhis.html

SHA256.csv records the checksums of the two source archives and extracted CSVs.
The Adult file has 24,215 rows and 577 columns. The income file contains ten
imputations per adult, linked by HHX and IMPNUM_A, not independent respondents.
Age restrictions and recoding are performed separately in the analysis scripts.

https://www.cdc.gov/nchs/policy/data-user-agreement.html
Statistical use only; no attempted identification or linkage to identifiable data.
Earlier Git revisions retain the previously bundled data; history is unchanged.
